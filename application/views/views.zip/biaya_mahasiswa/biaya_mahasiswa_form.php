<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Biaya_mahasiswa <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Jenis Biaya <?php echo form_error('jenis_biaya') ?></label>
          <select name="jenis_biaya" class="form-control" required>
<?php if($jenis_biaya==''){?>  
    <option value="">Silahkan pilih Jenis Mahasiswa</option>
<?php }else{?>
    <option value="<?php echo $jenis_biaya;?>"><?php echo $nm_jns_daftar;?></option>
<?php } ?>}
 <?php foreach($jd as $row){?>
    <option value="<?php echo $row->id_jns_daftar;?>"><?php echo $row->nm_jns_daftar;?></option>
 <?php } ?>
    </select>
        </div>
	    <div class="form-group">
            <label for="varchar">Acc <?php echo form_error('acc') ?></label>
            <input type="text" class="form-control" name="acc" id="acc" placeholder="Acc" value="<?php echo $acc; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Nama Biaya <?php echo form_error('nama_biaya') ?></label>
            <input type="text" class="form-control" name="nama_biaya" id="nama_biaya" placeholder="Nama Biaya" value="<?php echo $nama_biaya; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Jumlah Biaya <?php echo form_error('jumlah_biaya') ?></label>
            <input type="text" class="form-control" name="jumlah_biaya" id="jumlah_biaya" placeholder="Jumlah Biaya" value="<?php echo $jumlah_biaya; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Set Biaya Deskripsi <?php echo form_error('set_biaya') ?></label>
            <input type="text" class="form-control" name="set_biaya" id="set_biaya" placeholder="Set Biaya" value="<?php echo $set_biaya; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Status Biaya <?php echo form_error('status_biaya') ?></label>
            <input type="text" class="form-control" name="status_biaya" id="status_biaya" placeholder="Status Biaya" value="<?php echo $status_biaya; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Id User Set <?php echo form_error('id_user_set') ?></label>
            <input type="text" class="form-control" name="id_user_set" id="id_user_set" placeholder="Id User Set" value="<?php echo $id_user_set; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Id User Status <?php echo form_error('id_user_status') ?></label>
            <input type="text" class="form-control" name="id_user_status" id="id_user_status" placeholder="Id User Status" value="<?php echo $id_user_status; ?>" />
        </div>
	 
	    <div class="form-group">
            <label for="varchar">Id Smt <?php echo form_error('id_smt') ?></label>
            <input type="text" class="form-control" name="id_smt" id="id_smt" placeholder="Id Smt" value="<?php echo $id_smt; ?>" />
        </div>
	     <div class="form-group">
    <label for="varchar">Pilih Prodi <?php echo form_error('id_sms') ?></label>
    <select name="id_sms" class="form-control" required>
 <?php if($id_sms==''){?>
    <option value="">Silahkan pilih prodi</option>
<?php }else{ ?>
    <option value="<?php echo $id_sms?>"><?php echo $nm_lemb;?></option>
<?php }?>
 <?php foreach($sms as $row){?>
    <option value="<?php echo $row->id_sms;?>"><?php echo $row->nm_lemb;?></option>
 <?php } ?>
    </select>
        
        </div>
	    <input type="hidden" name="id_biaya" value="<?php echo $id_biaya; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('biaya_mahasiswa') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>