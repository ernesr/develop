<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Group Wa <?php echo $button ?></h2>
        <form action="<?php echo $action; ?>" method="post">
	    <div class="form-group">
            <label for="varchar">Nama Group <?php echo form_error('nama_group') ?></label>
            <input type="text" class="form-control" name="nama_group" id="nama_group" placeholder="Nama Group" value="<?php echo $nama_group; ?>" />
        </div>
	    <div class="form-group">
    <label for="varchar">Pilih Prodi <?php echo form_error('id_sms') ?></label>
    <select name="id_sms" class="form-control" required>
    <?php if($id_sms==''){?>
        <option value="">Silahkan pilih prodi</option>
    <?php }else{ ?>
        <option value="<?php echo $id_sms ?>"><?php echo $nm_lemb ?></option>
    <?php } ?>    
 <?php foreach($sms as $row){?>
    <option value="<?php echo $row->id_sms;?>"><?php echo $row->nm_lemb;?></option>
 <?php } ?>
    </select>
        
        </div>
	    <div class="form-group">
            <label for="varchar">Jenis Mahasiswa <?php echo form_error('jenis_mahasiswa') ?></label>
           <select name="jenis_mahasiswa" class="form-control" required>
    <?php if($jenis_mahasiswa==''){?>
        <option value="">Silahkan pilih Jenis Mahasiswa</option>
     <?php }else{?>
        <option value="<?php echo $jenis_mahasiswa ?>"><?php echo $nm_jns_daftar ?></option>
        <?php }?>
 <?php foreach($jd as $row){?>
    <option value="<?php echo $row->id_jns_daftar;?>"><?php echo $row->nm_jns_daftar;?></option>
 <?php } ?>
    </select>
</div>
	    <div class="form-group">
            <label for="varchar">Link <?php echo form_error('link') ?></label>
            <input type="text" class="form-control" name="link" id="link" placeholder="Link" value="<?php echo $link; ?>" />
        </div>
	    <div class="form-group">
            <label for="varchar">Tahun Ajaran <?php echo form_error('tahun_ajaran') ?></label>
           <select name="tahun_ajaran" class="form-control" required>
            <?php if($tahun_ajaran==''){?>
            <option value="">Silahkan Pilih Tahun Ajaran</option>
            <?php }else{ ?>
            <option value="<?php echo $tahun_ajaran?>"><?php echo $tahun_ajaran?></option>

            <?php } ?>    
            <option value="2022">2022</option>
            <option value="2023">2023</option>
            <option value="2024">2024</option>
            <option value="2025">2025</option>
            <option value="2026">2026</option>
            <option value="2027">2027</option>

</select>
        </div>
	    <input type="hidden" name="id_group" value="<?php echo $id_group; ?>" /> 
	    <button type="submit" class="btn btn-primary"><?php echo $button ?></button> 
	    <a href="<?php echo site_url('grupwa') ?>" class="btn btn-default">Cancel</a>
	</form>
    </body>
</html>